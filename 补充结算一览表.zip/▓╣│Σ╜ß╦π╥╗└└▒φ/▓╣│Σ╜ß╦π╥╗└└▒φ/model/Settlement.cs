﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace 补充结算一览表.model
{
    public class Settlement
    {
        public int settlementid { get; set; }
        public string settlementguid { get; set; }
        public string settlename { get; set; }
    }
}
