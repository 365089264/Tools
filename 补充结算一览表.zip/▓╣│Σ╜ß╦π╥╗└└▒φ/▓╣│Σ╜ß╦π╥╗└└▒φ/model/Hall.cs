﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace 补充结算一览表.model
{
    public class Hall
    {
        public string hallcode { get; set; }
        public int hallid { get; set; }
    }
}
