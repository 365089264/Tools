﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace 补充结算一览表.model
{
    public class Filmissue_Hall
    {
        public string filmissue_hallguid { get; set; }
        public string hallcode { get; set; }
        public int filmissueid { get; set; }
        public string hall_devicetypeguid { get; set; }
    }
}
