﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace 补充结算一览表.model
{
    public class SpecialValueHall
    {
        public string SpecialHallID { get; set; }
        public string EQ_TheaterCode { get; set; }
        public string DeviceID { get; set; }
    }
}
